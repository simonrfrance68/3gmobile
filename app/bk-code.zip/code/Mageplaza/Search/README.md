How to Install: https://docs.mageplaza.com/kb/installation.html

User Guide: https://docs.mageplaza.com/search-m2/