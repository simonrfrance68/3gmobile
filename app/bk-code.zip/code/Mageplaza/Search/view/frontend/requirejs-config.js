var config = {
    paths: {
        'algoliaBundle': 'Mageplaza_Search/js/internals/algoliaBundle.min',
        'algoliaCommon': 'Mageplaza_Search/js/internals/common'
    }
};
