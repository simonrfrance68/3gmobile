<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * CatalogRule data helper
 */
namespace Codazon\Shopbybrandpro\Helper;

class ShopbyAttribute extends \Codazon\Shopbybrandpro\Helper\Data
{
    
}
