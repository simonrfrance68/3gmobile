<?php
/**
 * Copyright © 2018 Codazon, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codazon\ShippingCostCalculator\Block;

class CountriesBox extends \Codazon\ShippingCostCalculator\Block\ShippingCostAbstract
{
    
}