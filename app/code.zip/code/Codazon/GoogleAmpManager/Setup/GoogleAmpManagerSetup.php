<?php
/**
* Copyright © 2020 Codazon. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Codazon\GoogleAmpManager\Setup;

use Magento\Eav\Setup\EavSetup;

class GoogleAmpManagerSetup extends EavSetup
{
    
    public function getDefaultEntities()
    {
        $entities = array (
        );
        return $entities;
    }
}
