<?php
/**
* Copyright © 2020 Codazon. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Codazon\SalesPro\Setup;

use Magento\Eav\Setup\EavSetup;

class SalesProSetup extends EavSetup
{
    
    public function getDefaultEntities()
    {
        $entities = array (
        );
        return $entities;
    }
}
