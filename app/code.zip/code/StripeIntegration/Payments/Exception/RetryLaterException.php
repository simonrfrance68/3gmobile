<?php

namespace StripeIntegration\Payments\Exception;

class RetryLaterException extends \Exception
{
}
