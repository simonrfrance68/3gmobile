<?php

namespace StripeIntegration\Payments\Exception;

class InvalidAddressException extends \Magento\Framework\Exception\LocalizedException
{

}
