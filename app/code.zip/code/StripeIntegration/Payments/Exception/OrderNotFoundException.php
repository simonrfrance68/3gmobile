<?php

namespace StripeIntegration\Payments\Exception;

class OrderNotFoundException extends \StripeIntegration\Payments\Exception\WebhookException
{

}
